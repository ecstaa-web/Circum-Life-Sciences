<?php
/**
 * Template Name: Cookies
 * Page template: cookies
 */
defined('ABSPATH') || exit;

<?php add_action('wp_head', static function () { echo '<style>
  .legal-content { max-width: 900px; margin: 0 auto; padding: 60px 20px; line-height: 1.8; }
  .legal-section { margin-bottom: 40px; }
  .legal-section h2 { font-size: 22px; color: var(--blue-dark); margin-bottom: 16px; margin-top: 32px; }
  .legal-section h3 { font-size: 16px; color: var(--blue-dark); margin-bottom: 12px; margin-top: 20px; font-weight: 600; }
  .legal-section p { color: var(--text-soft); margin-bottom: 12px; }
  .legal-section ul { margin-left: 20px; margin-bottom: 16px; }
  .legal-section li { color: var(--text-soft); margin-bottom: 8px; }
  .cookie-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
  .cookie-table th, .cookie-table td { border: 1px solid var(--border); padding: 12px; text-align: left; }
  .cookie-table th { background: var(--blue-50); color: var(--blue-dark); font-weight: 600; }
  .cookie-table td { color: var(--text-soft); }
</style>'; }, 20); ?>

get_header();
?>
<main class="page-content">
<section class="page-hero">
<div class="container">
<div class="page-hero-content">
<nav class="page-hero-breadcrumb"><a data-i18n="breadcrumb.home" href="<?php echo esc_url( circum_url('home') ); ?>">Accueil</a><span class="page-hero-breadcrumb-sep">/</span><span data-i18n="cookies.breadcrumb_current">Politique relative aux cookies</span></nav>
<h1 data-i18n="cookies.hero_title">Politique relative aux cookies</h1>
<p data-i18n="cookies.hero_subtitle">Informations sur l'utilisation des cookies et des technologies de suivi similaires.</p>
</div>
</div>
</section>

<section class="legal-content">
<div class="legal-section">
<h2 data-i18n="cookies.s1_title">1. Qu'est-ce qu'un cookie?</h2>
<p data-i18n="cookies.s1_p">Un cookie est un petit fichier texte stock? sur votre appareil (ordinateur, tablette, smartphone) lorsque vous visitez un site web. Les cookies permettent aux sites de vous reconna?tre lors de visites ult?rieures et de stocker des pr?f?rences.</p>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s2_title">2. Types de cookies que nous utilisons</h2>

<h3 data-i18n="cookies.s2_essential_title">Cookies essentiels</h3>
<p data-i18n="cookies.s2_essential_p">Ces cookies sont n?cessaires au fonctionnement du site web et ne peuvent pas ?tre d?sactiv?s. Ils permettent :</p>
<ul>
<li data-i18n="cookies.s2_essential_li1">La navigation sur le site</li>
<li data-i18n="cookies.s2_essential_li2">L'acc?s aux zones s?curis?es</li>
<li data-i18n="cookies.s2_essential_li3">L'?quilibre des charges sur nos serveurs</li>
</ul>

<h3 data-i18n="cookies.s2_perf_title">Cookies de performance</h3>
<p data-i18n="cookies.s2_perf_p">Ces cookies collectent des informations sur la fa?on dont vous utilisez notre site, permettant ? Circum Life Sciences SA d'am?liorer les performances :</p>
<ul>
<li data-i18n="cookies.s2_perf_li1">Pages visit?es et temps pass?</li>
<li data-i18n="cookies.s2_perf_li2">Messages d'erreur rencontr?s</li>
<li data-i18n="cookies.s2_perf_li3">Taux de conversion</li>
</ul>

<h3 data-i18n="cookies.s2_func_title">Cookies de fonctionnalit?</h3>
<p data-i18n="cookies.s2_func_p">Ces cookies permettent au site de m?moriser vos choix et pr?f?rences :</p>
<ul>
<li data-i18n="cookies.s2_func_li1">Langue pr?f?r?e</li>
<li data-i18n="cookies.s2_func_li2">Pr?f?rences d'affichage</li>
<li data-i18n="cookies.s2_func_li3">Informations de connexion</li>
</ul>

<h3 data-i18n="cookies.s2_mkt_title">Cookies de marketing</h3>
<p data-i18n="cookies.s2_mkt_p">Ces cookies suivent votre activit? de navigation pour afficher des publicit?s pertinentes :</p>
<ul>
<li data-i18n="cookies.s2_mkt_li1">Publicit?s cibl?es</li>
<li data-i18n="cookies.s2_mkt_li2">Contenu personnalis?</li>
<li data-i18n="cookies.s2_mkt_li3">Suivi des conversions publicitaires</li>
</ul>

<h3 data-i18n="cookies.s2_third_title">Cookies tiers</h3>
<p data-i18n="cookies.s2_third_p">Certains cookies sont plac?s par des tiers (Google, r?seaux sociaux) pour :</p>
<ul>
<li data-i18n="cookies.s2_third_li1">Analyser le trafic du site</li>
<li data-i18n="cookies.s2_third_li2">Mesurer l'efficacit? des campagnes publicitaires</li>
<li data-i18n="cookies.s2_third_li3">Fournir des fonctionnalit?s de partage sur les r?seaux sociaux</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s3_title">3. Cookies utilis?s sur notre site</h2>

<table class="cookie-table">
<thead>
<tr>
<th data-i18n="cookies.th_name">Nom du cookie</th>
<th data-i18n="cookies.th_type">Type</th>
<th data-i18n="cookies.th_duration">Dur?e</th>
<th data-i18n="cookies.th_purpose">Objectif</th>
</tr>
</thead>
<tbody>
<tr>
<td>_ga</td>
<td data-i18n="cookies.tbl_ga_type">Performance</td>
<td data-i18n="cookies.tbl_ga_dur">2 ans</td>
<td data-i18n="cookies.tbl_ga_purpose">Google Analytics - identification unique des visiteurs</td>
</tr>
<tr>
<td>_gid</td>
<td data-i18n="cookies.tbl_gid_type">Performance</td>
<td data-i18n="cookies.tbl_gid_dur">24 heures</td>
<td data-i18n="cookies.tbl_gid_purpose">Google Analytics - identification de session</td>
</tr>
<tr>
<td>PHPSESSID</td>
<td data-i18n="cookies.tbl_php_type">Essentiel</td>
<td data-i18n="cookies.tbl_php_dur">Session</td>
<td data-i18n="cookies.tbl_php_purpose">Gestion de session PHP</td>
</tr>
<tr>
<td>user_preference</td>
<td data-i18n="cookies.tbl_up_type">Fonctionnalit?</td>
<td data-i18n="cookies.tbl_up_dur">1 an</td>
<td data-i18n="cookies.tbl_up_purpose">Stockage des pr?f?rences utilisateur (langue, th?me)</td>
</tr>
<tr>
<td>lang</td>
<td data-i18n="cookies.tbl_lang_type">Fonctionnalit?</td>
<td data-i18n="cookies.tbl_lang_dur">1 an</td>
<td data-i18n="cookies.tbl_lang_purpose">S?lection de la langue de navigation</td>
</tr>
<tr>
<td>fbp</td>
<td data-i18n="cookies.tbl_fbp_type">Marketing</td>
<td data-i18n="cookies.tbl_fbp_dur">3 mois</td>
<td data-i18n="cookies.tbl_fbp_purpose">Pixel Facebook - suivi des conversions</td>
</tr>
</tbody>
</table>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s4_title">4. Consentement aux cookies</h2>
<p data-i18n="cookies.s4_p1">Lorsque vous visitez notre site pour la premi?re fois, un bandeau d'information vous demande d'accepter les cookies. Votre consentement couvre tous les cookies list?s ci-dessus, sauf les cookies essentiels qui sont toujours actifs.</p>
<p data-i18n="cookies.s4_p2">Vous pouvez modifier vos pr?f?rences de cookies ? tout moment en cliquant sur le lien de param?tres des cookies situ? en bas de page.</p>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s5_title">5. Gestion des cookies</h2>

<h3 data-i18n="cookies.s5_browser_title">Dans votre navigateur</h3>
<p data-i18n="cookies.s5_browser_p">La plupart des navigateurs vous permettent de refuser les cookies ou de vous avertir lorsqu'un cookie est envoy?. Les instructions varient selon le navigateur :</p>
<ul>
<li data-i18n="cookies.s5_li_chrome">Chrome: Param?tres &gt; Confidentialit? et s?curit? &gt; Cookies et autres donn?es de site</li>
<li data-i18n="cookies.s5_li_firefox">Firefox: Param?tres &gt; Vie priv?e &gt; Cookies et donn?es de site</li>
<li data-i18n="cookies.s5_li_safari">Safari: Pr?f?rences &gt; Confidentialit?</li>
<li data-i18n="cookies.s5_li_edge">Edge: Param?tres &gt; Confidentialit? et services &gt; Cookies</li>
</ul>

<h3 data-i18n="cookies.s5_prefs_title">Pr?f?rences sur notre site</h3>
<p data-i18n="cookies.s5_prefs_p">Vous pouvez g?rer vos pr?f?rences de cookies directement sur notre site via le centre de gestion des consentements.</p>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s6_title">6. Implications du refus des cookies</h2>
<p data-i18n="cookies.s6_p">Le refus de certains cookies peut affecter votre exp?rience sur notre site :</p>
<ul>
<li data-i18n="cookies.s6_li1">Les cookies essentiels ne peuvent pas ?tre d?sactiv?s</li>
<li data-i18n="cookies.s6_li2">Le refus des cookies de performance peut r?duire notre capacit? ? am?liorer le site</li>
<li data-i18n="cookies.s6_li3">Le refus des cookies de fonctionnalit? peut entra?ner une perte de pr?f?rences personnalis?es</li>
<li data-i18n="cookies.s6_li4">Le refus des cookies de marketing emp?chera la personnalisation du contenu</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s7_title">7. Donn?es de suivi tiers</h2>
<p data-i18n="cookies.s7_p1">Notre site utilise les services suivants qui placent des cookies :</p>
<ul>
<li data-i18n-html="cookies.s7_li_ga"><strong>Google Analytics</strong>: Analyse du trafic web</li>
<li data-i18n-html="cookies.s7_li_ads"><strong>Google Ads</strong>: Gestion des campagnes publicitaires</li>
<li data-i18n-html="cookies.s7_li_fbpixel"><strong>Facebook Pixel</strong>: Suivi des conversions publicitaires</li>
<li data-i18n-html="cookies.s7_li_linkedin"><strong>LinkedIn Insight</strong>: Suivi du comportement professionnel</li>
</ul>
<p data-i18n="cookies.s7_p2">Vous pouvez consulter les politiques de confidentialit? de ces prestataires pour en savoir plus sur leurs pratiques.</p>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s8_title">8. Dur?e de conservation</h2>
<p data-i18n="cookies.s8_p">Les cookies sont conserv?s selon leur type :</p>
<ul>
<li data-i18n="cookies.s8_li1">Cookies de session: supprim?s ? la fermeture du navigateur</li>
<li data-i18n="cookies.s8_li2">Cookies persistants: conserv?s selon leur dur?e de vie d?finie (g?n?ralement 1 an maximum)</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s9_title">9. S?curit? des cookies</h2>
<p data-i18n="cookies.s9_p">Nous utilisons des cookies s?curis?s pour prot?ger vos informations :</p>
<ul>
<li data-i18n="cookies.s9_li1">Transmission en HTTPS s?curis?e</li>
<li data-i18n="cookies.s9_li2">Drapeaux HttpOnly pour pr?venir l'acc?s JavaScript</li>
<li data-i18n="cookies.s9_li3">Drapeaux Secure pour garantir la transmission uniquement en HTTPS</li>
<li data-i18n="cookies.s9_li4">Protection contre les attaques CSRF</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s10_title">10. Modifications de cette politique</h2>
<p data-i18n="cookies.s10_p">Nous pouvons mettre ? jour cette politique relative aux cookies ? tout moment. Les modifications prendront effet d?s la publication sur le site. Nous vous encourageons ? consulter r?guli?rement cette politique.</p>
</div>

<div class="legal-section">
<h2 data-i18n="cookies.s11_title">11. Contact</h2>
<p data-i18n="cookies.s11_p1">Pour toute question concernant notre utilisation des cookies, veuillez nous contacter :</p>
<p data-i18n-html="cookies.s11_contact">Email: privacy@circumlifesciences.com<br/>
Adresse: Technop?le Zug, 6300 Zug, Suisse<br/>
T?l?phone: +41 (0) 22 123 45 67</p>
</div>
</section>
</main>
<?php get_footer();
