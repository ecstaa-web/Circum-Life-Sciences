<?php
/**
 * Template Name: ConfidentialitÃ©
 * Page template: privacy-policy
 */
defined('ABSPATH') || exit;

<?php add_action('wp_head', static function () { echo '<style>
  .legal-content { max-width: 900px; margin: 0 auto; padding: 60px 20px; line-height: 1.8; }
  .legal-section { margin-bottom: 40px; }
  .legal-section h2 { font-size: 22px; color: var(--blue-dark); margin-bottom: 16px; margin-top: 32px; }
  .legal-section h3 { font-size: 16px; color: var(--blue-dark); margin-bottom: 12px; margin-top: 20px; font-weight: 600; }
  .legal-section p { color: var(--text-soft); margin-bottom: 12px; }
  .legal-section ul { margin-left: 20px; margin-bottom: 16px; }
  .legal-section li { color: var(--text-soft); margin-bottom: 8px; }
</style>'; }, 20); ?>

get_header();
?>
<main class="page-content">
<section class="page-hero">
<div class="container">
<div class="page-hero-content">
<nav class="page-hero-breadcrumb"><a data-i18n="breadcrumb.home" href="<?php echo esc_url( circum_url('home') ); ?>">Accueil</a><span class="page-hero-breadcrumb-sep">/</span><span data-i18n="privacy.breadcrumb_current">Politique de confidentialité</span></nav>
<h1 data-i18n="privacy.hero_title">Politique de confidentialité</h1>
<p data-i18n="privacy.hero_subtitle">Nous respectons votre vie privée. Découvrez comment vos données personnelles sont traitées.</p>
</div>
</div>
</section>

<section class="legal-content">
<div class="legal-section">
<h2 data-i18n="privacy.s1_title">1. Introduction</h2>
<p data-i18n="privacy.s1_p">Circum Life Sciences SA (« nous ») est responsable de vos données personnelles. Cette politique de confidentialité explique comment nous collectons, utilisons, partageons et protégeons vos informations personnelles lorsque vous visitez notre site web.</p>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s2_title">2. Données collectées</h2>
<h3 data-i18n="privacy.s2_h1">Données fournies volontairement</h3>
<p data-i18n="privacy.s2_p1">Nous pouvons collecter les informations suivantes lorsque vous les fournissez volontairement :</p>
<ul>
<li data-i18n="privacy.s2_li1">Votre nom, prénom et adresse email</li>
<li data-i18n="privacy.s2_li2">Numéro de téléphone et numéro de fax</li>
<li data-i18n="privacy.s2_li3">Adresse postale et lieu de travail</li>
<li data-i18n="privacy.s2_li4">Informations de contenu que vous partagez avec nous</li>
<li data-i18n="privacy.s2_li5">Préférences de communication</li>
</ul>

<h3 data-i18n="privacy.s2_h2">Données collectées automatiquement</h3>
<p data-i18n="privacy.s2_p2">Lors de votre visite sur notre site, nous collectons automatiquement certaines données :</p>
<ul>
<li data-i18n="privacy.s2_li6">Adresse IP et type de navigateur</li>
<li data-i18n="privacy.s2_li7">Système d'exploitation utilisé</li>
<li data-i18n="privacy.s2_li8">Pages visitées et temps passé sur chaque page</li>
<li data-i18n="privacy.s2_li9">Historique de navigation sur notre site</li>
<li data-i18n="privacy.s2_li10">Cookies et données similaires</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s3_title">3. Utilisation des données</h2>
<p data-i18n="privacy.s3_p">Nous utilisons vos données personnelles pour :</p>
<ul>
<li data-i18n="privacy.s3_li1">Vous fournir les informations et services demandés</li>
<li data-i18n="privacy.s3_li2">Communiquer avec vous concernant nos produits et services</li>
<li data-i18n="privacy.s3_li3">Améliorer notre site web et nos services</li>
<li data-i18n="privacy.s3_li4">Analyser les tendances d'utilisation et la démographie des visiteurs</li>
<li data-i18n="privacy.s3_li5">Respecter nos obligations légales</li>
<li data-i18n="privacy.s3_li6">Prévenir les fraudes et les abus</li>
<li data-i18n="privacy.s3_li7">Vous envoyer des newsletters sur demande</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s4_title">4. Base juridique du traitement</h2>
<p data-i18n="privacy.s4_p">Le traitement de vos données personnelles est fondé sur :</p>
<ul>
<li data-i18n="privacy.s4_li1">Votre consentement explicite</li>
<li data-i18n="privacy.s4_li2">L'exécution d'un contrat avec vous</li>
<li data-i18n="privacy.s4_li3">Nos obligations légales</li>
<li data-i18n="privacy.s4_li4">Nos intérêts commerciaux légitimes</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s5_title">5. Partage des données</h2>
<p data-i18n="privacy.s5_p">Nous ne partageons pas vos données personnelles avec des tiers, sauf :</p>
<ul>
<li data-i18n="privacy.s5_li1">Si vous consentez explicitement</li>
<li data-i18n="privacy.s5_li2">Lorsque cela est nécessaire pour fournir un service</li>
<li data-i18n="privacy.s5_li3">Lorsque cela est exigé par la loi</li>
<li data-i18n="privacy.s5_li4">Avec nos prestataires de services qui traitent les données en notre nom sous contrat</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s6_title">6. Sécurité des données</h2>
<p data-i18n="privacy.s6_p">Nous mettons en place des mesures de sécurité techniques et organisationnelles pour protéger vos données contre l'accès non autorisé, la modification, la divulgation ou la destruction. Ces mesures incluent :</p>
<ul>
<li data-i18n="privacy.s6_li1">Chiffrement SSL/TLS de tous les transferts de données</li>
<li data-i18n="privacy.s6_li2">Authentification sécurisée</li>
<li data-i18n="privacy.s6_li3">Pare-feu et systèmes de détection d'intrusion</li>
<li data-i18n="privacy.s6_li4">Contrôle d'accès basé sur les rôles</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s7_title">7. Durée de conservation</h2>
<p data-i18n="privacy.s7_p">Nous conservons vos données personnelles uniquement aussi longtemps que nécessaire pour atteindre les objectifs pour lesquels elles ont été collectées, ou selon les dispositions légales applicables. Une fois qu'elles ne sont plus nécessaires, les données sont supprimées de manière sécurisée.</p>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s8_title">8. Vos droits</h2>
<p data-i18n="privacy.s8_p">En vertu des lois applicables sur la protection des données, vous avez le droit de :</p>
<ul>
<li data-i18n="privacy.s8_li1">Accéder à vos données personnelles</li>
<li data-i18n="privacy.s8_li2">Demander la rectification de données incorrectes</li>
<li data-i18n="privacy.s8_li3">Demander l'effacement de vos données</li>
<li data-i18n="privacy.s8_li4">Vous opposer au traitement de vos données</li>
<li data-i18n="privacy.s8_li5">Demander la limitation du traitement</li>
<li data-i18n="privacy.s8_li6">Demander la portabilité de vos données</li>
<li data-i18n="privacy.s8_li7">Retirer votre consentement à tout moment</li>
</ul>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s9_title">9. Exercice de vos droits</h2>
<p data-i18n="privacy.s9_p">Pour exercer vos droits ou pour toute question concernant vos données personnelles, veuillez nous contacter à :</p>
<p data-i18n-html="privacy.s9_contact">Email: privacy@circumlifesciences.com<br/>
Adresse: Technopôle Zug, 6300 Zug, Suisse</p>
</div>

<div class="legal-section">
<h2 data-i18n="privacy.s10_title">10. Modifications de cette politique</h2>
<p data-i18n="privacy.s10_p">Nous nous réservons le droit de modifier cette politique de confidentialité à tout moment. Les modifications prendront effet dès la publication sur le site. Votre utilisation continue du site suivant les modifications constitue votre acceptation des modifications.</p>
</div>
</section>
</main>
<?php get_footer();
